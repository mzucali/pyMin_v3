# Example_Data

In this folder you will find all of the files used to create the figures and supplement in the MinPlot manuscript. No additional manipulation is needed to run these files.
