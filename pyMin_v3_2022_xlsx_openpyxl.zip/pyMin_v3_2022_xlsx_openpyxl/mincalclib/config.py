# config.py
fileOUT = ''
fileIN = ''
