# pyMin_v3_2022_2023
January 2023

This is the DESKTOP version application
It uses the openpyxl to work with XLSX files

HOW TO USE IT

1) download the ZIP file
2) copy it in any folder in your PC and extract it
3) you need PYTHON installed with some modules
4) MANDATORY MODULES are: numpy, pandas, matplotlib, openpyxl, pandasgui (to install, use command on your terminal 'pip install nameofthemodule')
5) to start the application: 'python pyMin_v2.py'
